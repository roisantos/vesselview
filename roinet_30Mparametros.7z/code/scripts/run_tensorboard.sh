#!/bin/bash

cd /mnt/netapp2/Home_FT2/home/usc/cursos/curso040/.local/lib/python3.7/site-packages/tensorboard

python main.py --logdir="/mnt/netapp2/Home_FT2/home/usc/cursos/curso040/Documentos/tfg/codebase-light-velev/tfg_codebase_cesga/tensorboardLog/2024-11-13_18.07.56"

cd /mnt/netapp2/Home_FT2/home/usc/cursos/curso040/Documentos/tfg/codebase-light-velev/tfg_codebase_cesga