#!/bin/bash
squeue -h -j $SLURM_JOB_ID -O TimeLeft